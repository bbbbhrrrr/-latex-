# 山东大学学术海报LaTeX模板

## 简介
这是一个基于baposter文档类的山东大学学术海报模板，采用现代化设计和中文内容展示。

## 主要特色
- 🎨 使用山东大学官方色彩方案（深红色主题）
- 🌏 完善的中英文混排支持
- 📐 适用于A0纸张，竖向排版
- 🔧 模块化设计，易于修改内容
- ⚡ 一键编译脚本
- 📖 完整的使用文档

## 文件结构
```
├── poster.tex          # 主LaTeX模板文件
├── poster.bib          # 参考文献文件
├── baposter.cls        # baposter文档类
├── compile.bat         # 一键编译脚本
├── README.md           # 项目说明文件
├── 模板使用指南.md     # 详细使用指南
├── 颜色配置指南.md     # 颜色自定义指南
├── logo调整说明.md     # Logo调整说明
└── figures/            # 图片文件夹
    ├── logo.jpg        # 山东大学logo
    └── *.pdf          # 示例图片文件
```

## 使用说明

### 环境要求
- LaTeX发行版（推荐TeX Live或MiKTeX）
- 支持XeLaTeX编译器
- 中文字体支持（SimSun, SimHei等）

### 编译步骤

#### 方法一：使用编译脚本（推荐）
双击运行 `compile.bat` 文件，脚本会自动完成所有编译步骤。

#### 方法二：手动编译
1. 使用XeLaTeX编译器编译poster.tex
2. 运行BibTeX处理参考文献
3. 再次运行XeLaTeX编译（可能需要2-3次）

```bash
xelatex poster.tex
bibtex poster
xelatex poster.tex
xelatex poster.tex
```

### 自定义修改

#### 标题和作者信息
修改poster.tex中的标题和作者部分：
```latex
{您的研究标题}
作者姓名1, 作者姓名2, 作者姓名3
山东大学[学院名称]
email@sdu.edu.cn
```

#### 颜色主题
模板当前使用深红色主题，在poster.tex中修改颜色定义：
```latex
\definecolor{sduRed}{cmyk}{0,0.92,0.88,0.39}     % 山东大学深红色
\definecolor{sduLightRed}{cmyk}{0,0.78,0.75,0.25} % 配色红色
```

#### 内容模块
每个内容框使用\headerbox命令定义，模板提供6个主要板块：
- 引言/背景
- 方法/理论  
- 关键技术
- 实验设计/系统架构
- 实验结果
- 结论与展望

```latex
\headerbox{标题}{name=标识符,column=列号,below=上方模块,span=跨度}{
您的内容...
}
```

## 注意事项
1. 确保系统已安装所需的中文字体（SimSun、SimHei、Microsoft YaHei）
2. 必须使用XeLaTeX编译器以获得最佳中文支持，不要使用pdfLaTeX
3. 图片文件应放在figures/文件夹中
4. 修改logo时，请替换figures/logo.jpg文件或修改模板中的引用路径
5. 参考文献需要在poster.bib文件中定义

## 详细文档
- 📖 `模板使用指南.md` - 完整的使用说明和自定义指南
- 🎨 `颜色配置指南.md` - 详细的颜色配置选项
- 🖼️ `logo调整说明.md` - Logo尺寸和位置调整方法

## 模板结构
模板采用3列布局：
- 左列：引言、方法、技术、参考文献
- 中右列：实验设计、结果、结论（跨列显示）

## 技术支持
- 查看详细文档解决常见问题
- 检查LaTeX编译日志排查错误
- 参考baposter文档类官方文档

---
**模板版本**: 1.0  
**更新日期**: 2025年6月8日  
**维护方**: 山东大学
