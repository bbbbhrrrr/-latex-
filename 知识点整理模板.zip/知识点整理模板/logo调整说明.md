# Logo大小调整参考

## 当前设置
```latex
\includegraphics[height=0.08\textheight]{logo.jpg}
```
- 高度：页面高度的8%
- 适用于：标准A0海报
- 效果：适中大小，不会过分突出

## 其他推荐尺寸

### 选项1：较小logo（专业简洁）
```latex
\includegraphics[height=0.06\textheight]{logo.jpg}
```

### 选项2：中等logo（平衡显示）
```latex
\includegraphics[height=0.08\textheight]{logo.jpg}  % 当前设置
```

### 选项3：较大logo（突出学校标识）
```latex
\includegraphics[height=0.10\textheight]{logo.jpg}
```

### 选项4：固定尺寸（精确控制）
```latex
\includegraphics[height=6cm]{logo.jpg}        % 固定6厘米高
\includegraphics[width=8cm]{logo.jpg}         % 固定8厘米宽
\includegraphics[width=8cm,height=6cm,keepaspectratio]{logo.jpg}  % 保持比例
```

## 修改方法
1. 打开 `poster.tex` 文件
2. 找到第87行左右的logo设置：
   ```latex
   {\includegraphics[height=0.08\textheight]{logo.jpg}}
   ```
3. 修改其中的尺寸参数
4. 重新编译查看效果

## 注意事项
- 建议使用相对尺寸（如 `0.08\textheight`）而非固定尺寸，这样在不同纸张尺寸下都能正常显示
- 如果logo显示模糊，可能需要使用更高分辨率的图片文件
- logo文件必须放在 `figures/` 文件夹中
